# Documentation Statistics Report
Generated on 2025-03-26 10:44:15

## Overview
- Total Markdown Files:       18
- Total Directories:        8

## File Statistics
| File | Word Count | Headers | Links | Images |
|------|------------|---------|--------|---------|
| GAME_DESIGN.md |      496 | 35 | 0 | 0 |
| SUMMARY.md |       59 | 7 | 16 | 0 |
| roadmap/phases.md |      231 | 8 | 0 | 0 |
| roadmap/milestones.md |      741 | 33 | 0 | 0 |
| whitepaper/overview.md |      260 | 7 | 0 | 0 |
| whitepaper/technology.md |      519 | 23 | 0 | 0 |
| whitepaper/vision.md |      476 | 14 | 0 | 0 |
| whitepaper/tokenomics.md |      529 | 20 | 0 | 0 |
| README.md |      153 | 6 | 8 | 0 |
| blockchain/wallet-integration.md |      573 | 17 | 0 | 0 |
| blockchain/token-economy.md |      315 | 13 | 0 | 0 |
| blockchain/smart-contracts.md |      449 | 25 | 0 | 0 |
| blockchain/README.md |      299 | 15 | 0 | 0 |
| blockchain/nft-system.md |      440 | 23 | 0 | 0 |
| index.md |      138 | 5 | 8 | 0 |
| gameplay/README.md |      192 | 9 | 0 | 0 |
| gameplay/mechanics.md |      584 | 18 | 0 | 0 |
| reports/documentation_stats.md |      222 | 3 | 0 | 0 |

*Last updated: 2025-03-26 10:44:15*
